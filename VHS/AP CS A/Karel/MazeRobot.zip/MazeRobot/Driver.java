import kareltherobot.*;

public class Driver implements Directions
{
    public static void main(String[] args)
    {
        