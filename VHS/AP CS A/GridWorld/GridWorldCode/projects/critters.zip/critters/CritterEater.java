import info.gridworld.actor.*;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;

import java.awt.Color;
import java.util.ArrayList;

public class CritterEater extends Critter
{
    public void processActors(ArrayList <Actor> actors)
    {
        for (Actor a : actors)
        {
            if (!(a instanceof Rock))
                a.removeSelfFromGrid();
        }
    }
    
    public void makeMove(Location loc)
    {
        Grid <Actor> gr = getGrid();
        if (loc == null)
            removeSelfFromGrid();
        else
        {
            Location loc1 = getLocation();
            moveTo(loc);
            
            Critter critter1 = new Critter();
            critter1.putSelfInGrid(gr, loc1);
        }
    }
}